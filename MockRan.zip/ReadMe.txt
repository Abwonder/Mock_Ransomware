## General info
MockRan.exe is a Windows console application. It is a Mock Ransomware and minics the behaviour of crypto-ransomware. This benign software does not cause any damage to any hosts and their connected network.

## How to run: 
Method 1: Right click the MockRan.exe, and then select the option "Run as adminstrator" on the pop-up menu.
Method 2: Run the cmd.exe as adminstrator, and change the current directory to where the MockRan.exe is located. Then, type MockRan.exe and hit Enter to run it.